# Airbnb Rental Price Estimation
# Tools: Python, Pandas, Matplotlib, Scikit-learn

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Load dataset
data = pd.read_csv("airbnb_listings.csv")

print("First 5 rows:")
print(data.head())

print("\nDataset shape:", data.shape)

print("\nMissing values before cleaning:")
print(data.isnull().sum())

# Features and target
X = data.drop(columns=["listing_id", "price_per_night"])
y = data["price_per_night"]

numeric_features = [
    "guests", "bedrooms", "bathrooms", "number_of_reviews",
    "rating", "minimum_nights", "availability_days"
]
categorical_features = ["location", "room_type"]

# Preprocessing
numeric_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler())
])

categorical_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore"))
])

preprocessor = ColumnTransformer([
    ("num", numeric_pipeline, numeric_features),
    ("cat", categorical_pipeline, categorical_features)
])

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Regression model
model = Pipeline([
    ("preprocessor", preprocessor),
    ("regressor", LinearRegression())
])

# Train
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Evaluation
mae = mean_absolute_error(y_test, y_pred)
rmse = mean_squared_error(y_test, y_pred) ** 0.5
r2 = r2_score(y_test, y_pred)

print(f"\nMean Absolute Error (MAE): {mae:.2f}")
print(f"Root Mean Squared Error (RMSE): {rmse:.2f}")
print(f"R² Score: {r2:.4f}")

# Compare actual and predicted prices
comparison = pd.DataFrame({
    "Actual Price": y_test.values,
    "Predicted Price": y_pred.round(2)
})
print("\nActual vs Predicted Prices:")
print(comparison.head(10))

# Predict a new Airbnb listing
new_listing = pd.DataFrame([{
    "location": "Downtown",
    "room_type": "Entire home",
    "guests": 4,
    "bedrooms": 2,
    "bathrooms": 2,
    "number_of_reviews": 120,
    "rating": 4.7,
    "minimum_nights": 2,
    "availability_days": 200
}])

predicted_price = model.predict(new_listing)[0]
print(f"\nEstimated Airbnb Price per Night: {predicted_price:.2f}")

# Feature impact using regression coefficients
feature_names = model.named_steps["preprocessor"].get_feature_names_out()
coefficients = model.named_steps["regressor"].coef_

importance = pd.DataFrame({
    "feature": feature_names,
    "coefficient": coefficients,
    "absolute_impact": abs(coefficients)
}).sort_values("absolute_impact", ascending=False)

print("\nTop Factors Affecting Rental Price:")
print(importance.head(12)[["feature", "coefficient"]])

# Visualization 1: guests vs price
plt.figure(figsize=(8, 5))
plt.scatter(data["guests"], data["price_per_night"], alpha=0.6)
plt.xlabel("Number of Guests")
plt.ylabel("Price per Night")
plt.title("Number of Guests vs Airbnb Rental Price")
plt.tight_layout()
plt.savefig("guests_vs_price.png", dpi=150)
plt.show()

# Visualization 2: actual vs predicted
plt.figure(figsize=(8, 5))
plt.scatter(y_test, y_pred, alpha=0.6)
plt.xlabel("Actual Price per Night")
plt.ylabel("Predicted Price per Night")
plt.title("Actual vs Predicted Airbnb Rental Prices")
plt.tight_layout()
plt.savefig("actual_vs_predicted.png", dpi=150)
plt.show()

# Visualization 3: room type price comparison
room_price = data.groupby("room_type", dropna=False)["price_per_night"].mean()

plt.figure(figsize=(8, 5))
room_price.plot(kind="bar")
plt.xlabel("Room Type")
plt.ylabel("Average Price per Night")
plt.title("Average Airbnb Price by Room Type")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("room_type_price.png", dpi=150)
plt.show()
