# Airbnb Rental Price Estimation

## Synopsis
This project focuses on estimating the rental price of an Airbnb property based on information such as location, room type, number of guests, bedrooms, bathrooms, reviews, rating, minimum nights, and availability. Students analyze the dataset and build a regression model to estimate rental prices.

## Objectives
- Explore Airbnb property data.
- Analyze factors affecting rental prices.
- Visualize price differences.
- Prepare the dataset.
- Train a regression model.
- Estimate rental prices.

## Tools
Python, Pandas, Matplotlib, Scikit-learn

## Dataset Features
- listing_id
- location
- room_type
- guests
- bedrooms
- bathrooms
- number_of_reviews
- rating
- minimum_nights
- availability_days
- price_per_night

Target:
- price_per_night — estimated nightly rental price

## Data Preparation
- Loaded Airbnb listing data using Pandas.
- Checked for missing values.
- Filled missing numerical values using median values.
- Filled missing categorical values using the most frequent value.
- Standardized numerical features.
- One-hot encoded categorical features.
- Split the dataset into training and testing sets.

## Machine Learning Algorithm
Linear Regression is used as the regression model.

## Evaluation
The program calculates:
- Mean Absolute Error (MAE)
- Root Mean Squared Error (RMSE)
- R² Score
- Actual vs predicted rental-price comparison
- Estimated price for a new Airbnb listing
- Important factors based on regression coefficients

It also generates:
- `guests_vs_price.png`
- `actual_vs_predicted.png`
- `room_type_price.png`

## How to Run
1. Install Python.
2. Open a terminal in this project folder.
3. Install dependencies:
   pip install -r requirements.txt
4. Run:
   python airbnb_rental_price_estimation.py

## Dataset Note
The included Airbnb dataset is synthetic and intended for educational/classroom machine-learning practice. It does not contain real Airbnb listing records.
